const mongoose = require('mongoose');


const jobSchema = new mongoose.Schema({
   ministry : String,
   issues : String,
   notes : String,
   images: [String],
   attachments : [String],
   createdby : String,
   createdon : {
      type: Date,
      default: Date.now
    },
   jobstatus :{
      type : String,
      default: 'Started'
   },
   
}) 

// creating jobs collection in Mongodb

const Job = new mongoose.model("Job" , jobSchema);
module.exports = Job;



// const Image = new mongoose.model("Image" , jobSchema);
// module.exports = Image;




