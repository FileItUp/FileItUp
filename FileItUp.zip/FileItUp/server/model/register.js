const mongoose = require('mongoose');

const userdataSchema = new mongoose.Schema({
    accounttype : String,
    represents : {
        type : String,
        required: true
    },
    name : {
        type : String,
        required: true
    },
    cpr : {
        type : Number,
        required : true
    },
    governerate : {
        type : String,
        required: true
    },
    sector : {
        type : String,
        required: true
    },
    mobile : {
        type: Number,
        required: true,
        unique: true
    },
    email : {
        type: String,
        required: true,
        unique: true
    },
    password : {
        type: String,
        required: true
    },
    cpassword : {
        type: String,
        required: true
    },
    status : {
        type: String,
        default: 'Inactive'
    }
})

// creating collection in Mongodb

const UserData = new mongoose.model("UserData",userdataSchema);
module.exports = UserData;