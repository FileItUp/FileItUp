function changeMenuP()
{
  document.getElementById("parlMenu").hidden= false;
  document.getElementById("muncMenu").hidden= true;  
}

function changeMenuM()
{
  document.getElementById("parlMenu").hidden= true;
  document.getElementById("muncMenu").hidden= false;
    
}

