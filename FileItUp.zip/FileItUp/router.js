var express= require("express");
const req = require("express/lib/request");
const res = require("express/lib/response");
const UserData = require("./server/model/register");
const Job = require("./server/model/jobs");
const nodemailer = require("nodemailer");
const path = require('path');
const fs = require('fs');

var router = express.Router();

router.use(express.static('./'));

const upload = require('./server/database/uploadfunc');

//route for dashboard

router.get('/dashboard',(req,res)=>{
    if(req.session.user){
        res.render('dashboard',{user:req.session.user})

    }else{
        res.send("Unauthorized User")
    }

})

//route for logout

router.get('/logout',(req,res)=>{
    req.session.destroy(function(err){
        if(err){
            console.log(err);
            res.send("Error")
        }else{
            res.render('base', {title:"Logout", logout:"Logged Out Successfully."})
        }
    })  
})

//route for Signup
router.get('/signup',(req,res)=>{
    res.render('signup',{title:"Sign Up"})
})

//route for Forget

router.get('/forget',(req,res)=>{
    res.render('forget',{title:"Forget Your Password"})
})

//route to base from signup

router.get('/signin',(req,res)=>{
    res.render('base',{title:"Existing Account SignIn"})
})

// route to base from dashboard

router.get('/base',(req,res)=>{
    req.session.destroy(function(err){
        if(err){
            console.log(err);
            res.send("Error")
        }else{
            res.render('base', {title:"Logout", logout:"Logged Out Successfully."})
        }
    })
})

router.post('/userdata/:id/enable', async (req, res) => {
  try {
    const userInfo = await UserData.findById(req.params.id);
    const enablerid = userInfo.email;
    if(userInfo.status !="Active" ){
     
        await userInfo.updateOne(
          { $set: { status: 'Active' } }
        ); 
      
        let testAccount = await nodemailer.createTestAccount();

        // create reusable transporter object using the default SMTP transport
        const transporter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'fileitup1@gmail.com',
                pass: 'aphswtgenqphrcqk'
            }
     });
     
   // send mail with defined transport object
let message = {
 from: '"FileItUp Admin Team" <foo@example.com>', // sender address
 to: enablerid, // list of receivers
 subject: "FileItUp : Job Status Update ", // Subject line
 text: "Hello your account is activated now.", // plain text body
 html: "Hello your account is activated now.", // html body
}    
transporter.sendMail(message).then((info)=>{
  
})
  const userdata = await UserData.find();
  res.render('admin', { userdata: userdata });
}else{
      res.send('User status is already Active.')
    }
  } catch (err) {
    console.error(err);
    res.status(500).render('base')
  }
});

router.post('/userdata/:id/delete', async (req, res) => {
  const userId = req.params.id;
  try {
    // Delete the job with the specified ID
    const result = await UserData.deleteOne({ _id: userId });
    if (result.deletedCount === 1) {
      const userdata = await UserData.find();
      res.render('admin', { userdata: userdata });
    } else {
      throw new Error('Failed to delete user');
    }
  } catch (error) {
    console.error(error);
    res.status(500).render('base')
  }
});

router.get('/viewjob', async (req, res) => {
  try {
    // fetch the data from MongoDB Atlas
    if(email == "fileitup1@gmail.com" ){

    const userDetails = await UserData.find();
    const jobs = await Job.find();
    // render the HTML page with the data
    res.render('viewJobs', { jobs: jobs });
    }else{
      res.render('dashboard', {title:"Access Restricted", BadCred:"Oops! You don't have access to view jobs."})
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Internal server error');
  }
});


router.post('/jobs/:id/complete', async (req, res) => {
   try {

        const compNotes = req.body.completionNotes;
        const job = await Job.findById(req.params.id);
        if( job.jobstatus != 'Completed'){
        job.jobstatus = 'Completed';
        await job.save(); 
      
        const jobemail = job.createdby;
        const jobid = job._id;

        let testAccount = await nodemailer.createTestAccount();

        // create reusable transporter object using the default SMTP transport
        const transporter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'fileitup1@gmail.com',
                pass: 'aphswtgenqphrcqk'
            }
     });
     
   // send mail with defined transport object
let message = {
 from: '"FileItUp Admin Team" <foo@example.com>', // sender address
 to: jobemail, // list of receivers
 subject: "FileItUp : Job Status Update ", // Subject line
 text: "Hello JOB ID : P" + jobid.toString().slice(0, 6) + " is completed successfully.", // plain text body
 html: "Hello, <br><br> <b>JOB ID :</b> P" + jobid.toString().slice(0, 6) + "<br><b>Status :</b> Completed"+"<br><b>Completion Notes :</b>"+compNotes+"<br> <h3>Thank You.</h3>", // html body
}    
transporter.sendMail(message).then((info)=>{
 return res.render('dashboard');
})
    
}else{
  res.send('Job Status is already completed.')
}
  }
catch (error) {
res.status(500).render('base')

}


});

router.post('/jobs/:id/delete', async (req, res) => {
  const jobId = req.params.id;
  try {
    // Delete the job with the specified ID
    const result = await Job.deleteOne({ _id: jobId });
    if (result.deletedCount === 1) {
      const jobs = await Job.find();
      res.render('viewJobs', { jobs: jobs });
    } else {
      throw new Error('Failed to delete job');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

router.get('/uploads/:id/attachment', (req, res) => {
  const jobId = req.params.id;
  Job.findById(jobId, (err, job) => {
    if (err) {
      console.log(err);
      res.status(500).send('An error occurred while retrieving the job');
    } else {
      if (job && job.attachments) {
        const attachmentPath = `./uploads/${job.attachments}`;
        res.download(attachmentPath, 'Attachment.pdf', (err) => {
          if (err) {
            console.log(err);
            res.status(500).send('An error occurred while downloading the attachment');
          }
        });
      } else {
        res.status(404).send('Attachment not found');
      }
    }
  });
});


router.post('/upload', upload.fields([{ name: 'images', maxCount: 5 },{ name: 'attachments', maxCount: 5 }]), (req, res) => {
    const jobData = new Job({
      ministry : req.body.selectedMinistry,
      issues : req.body.selectedIssue,
      notes : req.body.notes,
      name: req.body.name,
      createdby : email,
      images: req.files.images.map(file => file.filename),
      attachments : req.files.attachments.map(file => file.filename),
    });
  
    jobData.save((err) => {
      if (err) {
        console.log(err);
        res.status(500).render('dashboard', {title:"Job Creation Failed", unSent:"Something went wrong. Your Issue has not reported"})
      } else {
        res.render('dashboard', {title:"Job Created", Sent:"Your Issue has been reported successfully"})
      }
    });
  });

//route to register

router.post('/register',async (req,res)=>{
    try {
        const password = req.body.password;
        const cpassword = req.body.cpassword;

        if(password === cpassword){

            const registerUser = new UserData({

                accounttype : req.body.userType,
                represents : req.body.represents,
                name : req.body.name,
                cpr : req.body.cpr,
                governerate : req.body.governerate,
                sector : req.body.sector,
                mobile : req.body.mobile,
                email : req.body.email,
                password : req.body.password,
                cpassword : req.body.cpassword
            })

            const registered = await registerUser.save();
            res.status(201).render('signup', {title:"Acknowledgement",
            Verify:"You have successfully created the account and the detials have been sent for verfication.Once your details are verified you will recieve an acknowledge mail."})

        }else{
            res.send("Password did not matched")
        }
      
    } catch (error) {
      res.status(400)
      
    }
})

// route to dashboard from login

let email;

router.post('/login', async (req, res) => {
 
  try {
    email = req.body.email;
    const password = req.body.password;
    const usertype = req.body.userType;

    const userDetails = await UserData.findOne({ email: email },);
    if (usertype=="admin" && userDetails.accounttype=="admin" && userDetails.email === email && userDetails.password === password && userDetails.status == "Active") {
      req.session.user = req.body.email;
      const userdata = await UserData.find();
      res.render('admin', { userdata: userdata });
      // res.status(201).render('/route/admin', { jobs: jobs });
    }
    else if (usertype=="member" && userDetails.accounttype=="Organization" && userDetails.email === email && userDetails.password === password && userDetails.status == "Active") {
      req.session.user = req.body.email;
      res.status(201).redirect('/route/dashboard');
      //res.status(201).render('dashboard')
    } else {
      res.render('base', {title:"Access Restricted", BadCred:"Oops! You account is not active yet."})
    }
  } catch (error) {
    res.status(400);
  }
});


//route to sendMail

router.post('/sendMail',async (req,res)=>{
    try {
        const email = req.body.email;
        const pwd = await UserData.findOne({email:email},{password : 1, _id : 0});
        
        const useremail = await UserData.findOne({email:email});
            
        if(useremail.email === email){
           
         let testAccount = await nodemailer.createTestAccount();
 
         // create reusable transporter object using the default SMTP transport
         const transporter = nodemailer.createTransport({
             host: 'smtp.gmail.com',
             port: 465,
             secure: true,
             auth: {
                 user: 'fileitup1@gmail.com',
                 pass: 'aphswtgenqphrcqk'
             }
         });
         
       // send mail with defined transport object
   let message = {
     from: '"FileItUp Admin Team" <foo@example.com>', // sender address
     to: req.body.email, // list of receivers
     subject: "FileItUp : Lost Password Retreival", // Subject line
     text: "Hello your password is :" + pwd.toString(), // plain text body
     html: "Hello your password is :" + pwd.toString(), // html body
   }    
    transporter.sendMail(message).then((info)=>{
     return res.render('forget', {title:"Password Sent", Sent:"Password Sent Successfully"})
    })
 }

        
}
catch (error) {
    res.status(500).render('forget', {title:"Invalid Credentials", BadCred:"Invalid Email Entered"})
    
  }
})

module.exports=router;